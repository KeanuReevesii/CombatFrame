﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleFacade
{
    private static BattleFacade _instance;
    public static BattleFacade Instance
    {
        get
        {
            if (_instance == null)
                _instance = new BattleFacade();
            return _instance;
        }
    }



    private BattleSystem battleSystem = null;


    private BattleFacade()
    { }

    public void Initinal()
    {

        battleSystem = new BattleSystem(this);

    }

    public void Release()
    {
        battleSystem.Relese(); 
    }
    // 更新
    public void Update()
    {
        // 玩家輸入
        // InputProcess();

        // 遊戲系統更新
        battleSystem.Update();


    }

}

