using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BattleStateBase :IState
{

    public BattleType battleType;

    protected BattleStateControl m_Controller=null;

    public BattleStateBase(BattleStateControl controller)
    {
        m_Controller = controller;
    }

    public abstract void Init();
    public abstract void Update();
    public abstract void Relese();
}
