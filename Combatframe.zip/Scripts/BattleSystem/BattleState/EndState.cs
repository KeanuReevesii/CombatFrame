using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndState : BattleStateBase
{
    public EndState(BattleStateControl controller) : base(controller)
    {
    }

    public override void Init()
    {
        //��UI
        //CloseBattle

    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public void CloseBattle()
    {
        //�ص�ѡ��ؿ� ��  BeginState
        m_Controller.SetState(new BeginState(m_Controller));

    }
    public override void Update()
    {
        throw new System.NotImplementedException();
    }
}
