using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleState : BattleStateBase
{

    private RoundSystem roundSystem;
    private CharacterSystem characterSystem;

    public BattleState(BattleStateControl controller) : base(controller)
    {
    }

    public override void Init()
    {

        roundSystem = new RoundSystem(BattleFacade.Instance);
        characterSystem = new CharacterSystem(BattleFacade.Instance);
        //����С��


    }

    public override void Update()
    {
        //ս���������
        Reason();
        //ս������
        Action();
        

       
    }

    private void Reason()
    {
        //if(ս����������)
        //m_Controller.SetState(new EndState(m_Controller));
    }

    private void Action()
    {

        roundSystem.Update();

    }

    public override void Relese()
    {
        //�ͷ��ڴ�
    }
}
