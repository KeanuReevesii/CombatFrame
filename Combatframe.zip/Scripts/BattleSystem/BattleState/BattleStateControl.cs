using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BattleType
{
    NullTrans = -1,
    Begin = 0,
    Battle =1,
    End = 2,
    Max =99

}

public class BattleStateControl
{

    private Dictionary<BattleType, BattleStateBase> stateDic = new Dictionary<BattleType, BattleStateBase>();

    private BattleStateBase m_state;
    public BattleStateControl()
    { }


    public void AddState(BattleStateBase state)
    {
        if (!stateDic.ContainsKey(state.battleType))
            stateDic.Add(state.battleType, state);

    }

    public void SetState(BattleStateBase state)
    {
        if (m_state != null)
            m_state.Relese();

        m_state = state;
    }
    public void Init()
    {
        m_state.Init();
    }
    public void Update()
    {
        m_state.Update();
    }
    public void Release ()
    {
        m_state.Relese();
    }
}
