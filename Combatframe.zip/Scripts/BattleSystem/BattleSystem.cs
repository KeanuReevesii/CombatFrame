    using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleSystem : SystemBase
{
    public BattleStateControl stateControl;

    public BattleSystem(BattleFacade battleFacade) : base(battleFacade)
    {
        Init();
    }
    public override void Init()
    {
        stateControl = new BattleStateControl();
        stateControl.Init();

        //״̬��ʼ����
        //���ӵ� stateControl.add  ����


    }

    public override void Relese()
    {
        stateControl.Release();

    }

    public override void Update()
    {
        stateControl.Update();

    }
}
