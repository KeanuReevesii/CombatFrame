using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SystemBase 
{
    protected BattleFacade m_BattleFacade = null;
    public SystemBase(BattleFacade battleFacade)
    {
        m_BattleFacade = battleFacade;
    }
    public abstract void Init();
    public abstract void Update();
    public abstract void Relese();
}
