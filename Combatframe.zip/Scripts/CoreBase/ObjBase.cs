﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ObjBase  {

    public GameObject m_gameObject;

    public abstract void Init();
    public abstract void Release();
    public abstract void Update();
    public abstract void OnCreat();
}
