﻿using UnityEngine;
using System.Collections;

public class DataBase
{
    public int ID;
    public string Name;
    
}
