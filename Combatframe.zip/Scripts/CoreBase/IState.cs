﻿using UnityEngine;
using System.Collections;

public interface IState
{
     void Init();
     void Update();
     void Relese();
}
