﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ModelManager
{
    private static ModelManager _instance;
    public static ModelManager Instance
    {
        get
        {
            if (_instance == null)
                _instance = new ModelManager();
            return _instance;
        }
    }

    public Dictionary<string, ModelBase> modelDic = new Dictionary<string, ModelBase>();

    public void InitModel()
    {
        CharacterModel characterModel = new CharacterModel();
        modelDic.Add(characterModel.ModelName, characterModel);
        
    }


    public ModelBase GetModel(string modelName)
    {
        return modelDic[modelName];
    }
}
