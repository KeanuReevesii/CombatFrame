﻿using UnityEngine;
using System.Collections;

public class ModelBase
{
    public string ModelName;


}
