﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundSystem : SystemBase
{
    private RoundStateController stateControl;
    public RoundSystem(BattleFacade battleFacade) : base(battleFacade)
    {
        Init();
    }

    public override void Init()
    {
        stateControl = new RoundStateController();
        stateControl.Init();
        //==开始先进入回合开始
        stateControl.SetState(new RoundBegin(stateControl));
    }

    public override void Relese()
    {
        stateControl.Release();
    }

    public override void Update()
    {
        stateControl.Update();
    }
}
