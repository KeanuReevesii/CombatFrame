﻿using UnityEngine;
using System.Collections;

public abstract class RoundStateBase:IState
{

    public RoundType battleType;

    protected RoundStateController m_Controller = null;

    public RoundStateBase(RoundStateController controller)
    {
        m_Controller = controller;
    }

    public abstract void Init();
    public abstract void Update();
    public abstract void Relese();
}
