﻿using UnityEngine;
using System.Collections;


public class RoundEnd : RoundStateBase
{

    public RoundEnd(RoundStateController controller) : base(controller)
    {
    }
    public override void Init()
    {
     
    }

    public override void Relese()
    {
      
    }

    public override void Update()
    {
        //==是否超时判断 继续的情况下  if（）
         m_Controller.SetState(new RoundBegin(m_Controller));
        //else ===设定胜负条件


    }
}
