﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundAttackBefor : RoundStateBase
{

    public RoundAttackBefor(RoundStateController controller) : base(controller)
    {
    }

    public override void Init()
    {
        throw new System.NotImplementedException();
    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public override void Update()
    {
        //播动画
        m_Controller.SetState(new RoundAttackAfter(m_Controller));
    }
}
