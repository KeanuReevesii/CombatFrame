﻿using UnityEngine;
using System.Collections;

public class RoundBegin : RoundStateBase
{

    public RoundBegin(RoundStateController controller) : base(controller)
    {
    }
    public override void Init()
    {
     
    }

    public override void Relese()
    {

    }

    public override void Update()
    {
        //==统计战斗力之类的
        m_Controller.SetState(new RoundFight(m_Controller));
    }
}
