﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundFight : RoundStateBase
{

    public RoundFight(RoundStateController controller) : base(controller)
    {
    }

    public override void Init()
    {
        throw new System.NotImplementedException();
    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public override void Update()
    {
        //播动画
        //设计一个标记

        //if(播动画结束)
        m_Controller.SetState(new RoundAttackBefor(m_Controller));
    }
}
