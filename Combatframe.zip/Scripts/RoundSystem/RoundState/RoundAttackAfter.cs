﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundAttackAfter : RoundStateBase
{

    public RoundAttackAfter(RoundStateController controller) : base(controller)
    {
    }

    public override void Init()
    {
        throw new System.NotImplementedException();
    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public override void Update()
    {
        //播动画
        m_Controller.SetState(new RoundEnd(m_Controller));
    }
}
