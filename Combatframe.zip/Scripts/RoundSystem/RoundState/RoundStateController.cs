﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum RoundType
{
    NullTrans = -1,
    RoundBegin = 0,
    RoundIng = 1,
    RoundEnd = 2,
    Max = 99,
}


public class RoundStateController  {

    private Dictionary<RoundType, RoundStateBase> stateDic = new Dictionary<RoundType, RoundStateBase>();

    private RoundStateBase m_currState;
    public RoundStateController()
    { }


    public void AddState(RoundStateBase state)
    {
        if (!stateDic.ContainsKey(state.battleType))
            stateDic.Add(state.battleType, state);

    }

    public void SetState(RoundStateBase state)
    {
        if (m_currState != null)
            m_currState.Relese();

        m_currState = state;
    }
    public void Init()
    {
        m_currState.Init();
    }
    public void Update()
    {
        m_currState.Update();
    }
    public void Release()
    {
        m_currState.Relese();
    }
}
