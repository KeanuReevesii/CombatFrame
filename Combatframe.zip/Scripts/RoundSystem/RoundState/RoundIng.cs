﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 根据流程这个被划分到其他状态阶段中了
/// </summary>

public class RoundIng : RoundStateBase
{

    public RoundIng(RoundStateController controller) : base(controller)
    {
    }
    public override void Init()
    {
        throw new System.NotImplementedException();
    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public override void Update()
    {
        //==发动攻击动画等等
        m_Controller.SetState(new RoundEnd(m_Controller));
    }
}
