﻿using UnityEngine;
using System.Collections;

public class CharacterObj : ObjBase
{
    //m_gameObject
    public CharacterData characterData;
    //SkillCore

    public override void Init()
    {
        //最好把模型添加到场中中的统一一个父结点上
        m_gameObject = GameObject.Instantiate(Resources.Load<GameObject>(characterData.ResPath));
        //m_gameObject.parent = root.transfrom;
    }

    public override void OnCreat()
    {
        //添加SkillCore
    }

    public void SetData(CharacterData character)
    {
        characterData = character;
    }

    public override void Release()
    {
       
    }

    public override void Update()
    {
        //如果需要播放技能
        //SkillCore.play();
    }

   
}
