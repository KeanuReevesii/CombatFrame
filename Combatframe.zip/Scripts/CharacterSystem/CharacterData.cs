﻿using UnityEngine;
using System.Collections;

public class CharacterData : DataBase
{
    /// <summary>
    /// 等同于血量，任何战力变化时需进行战力是否归零的判定，且可触发技能优先级高	于胜负判定；战力高低决定出手顺序；
    /// </summary>
    public int CombatCap;

    ///
    ///百分比提升伤害
    ///
    public int Attack;

    ///
    ///减少受到的普通攻击和普通技能伤害
    ///
    public int Def;

    ///
    ///所有伤害类型都需最后与双方王者等级差的相关系数相乘才为最终伤害数值（最小	为0）；
    ///
    public int KingLv;


    public string ResPath;
}
