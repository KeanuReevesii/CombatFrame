﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterSystem : SystemBase {


    private Dictionary<int, CharacterObj> characterLeftDic;
    private Dictionary<int, CharacterObj> characterRightDic;
    private CharacterModel characterModel;

    private CharacterObj leftcharacterObj = new CharacterObj();
    private CharacterObj rightcharacterObj = new CharacterObj();


    public CharacterSystem(BattleFacade battleFacade) : base(battleFacade)
    {
        Init();
    }
    public override void Init()
    {
        characterLeftDic = new Dictionary<int, CharacterObj>();
        characterRightDic = new Dictionary<int, CharacterObj>();

        //服务器下发的CharacterModel 
        //角色生成     setData(characterData)
        characterModel = (CharacterModel) ModelManager.Instance.GetModel("CharacterModel");
        //============第二种逻辑
        leftcharacterObj = new CharacterObj();
        rightcharacterObj = new CharacterObj();
       
        for (int i = 0; i < characterModel.leftParticipationList.Count; i++)
        {
            //获取每一个形象放到同一个父结点上
            leftcharacterObj.SetData(characterModel.GetCharacterDataByID(characterModel.leftParticipationList[i]));
            leftcharacterObj.Init();
            leftcharacterObj.OnCreat();//添加技能的组件
           // characterLeftDic.Add(characterObj.characterData.ID, characterObj);

        }
        for (int i = 0; i < characterModel.leftParticipationList.Count; i++)
        {
            //获取每一个形象放到同一个父结点上
            leftcharacterObj.SetData(characterModel.GetCharacterDataByID(characterModel.leftParticipationList[i]));
            leftcharacterObj.Init();
            leftcharacterObj.OnCreat();//添加技能的组件
                                       // characterLeftDic.Add(characterObj.characterData.ID, characterObj);

        }
        //========================第二种逻辑End

        //===============第一种逻辑
        //characterModel.  Factory
        //CharacterObj characterObj;
        //for (int i = 0; i < characterModel.leftParticipationList.Count; i++)
        //{
        //    characterObj = new CharacterObj();
        //    characterObj.SetData(characterModel.GetCharacterDataByID(characterModel.leftParticipationList[i]));
        //    characterObj.Init();
        //    characterObj.OnCreat();//添加技能的组件
        //    characterLeftDic.Add(characterObj.characterData.ID, characterObj);

        //}


        //for (int i = 0; i < characterModel.rightParticipationList.Count; i++)
        //{
        //    characterObj = new CharacterObj();
        //    characterObj.SetData(characterModel.GetCharacterDataByID(characterModel.rightParticipationList[i]));
        //    characterObj.Init();
        //    characterObj.OnCreat();//添加技能的组件
        //    characterRightDic.Add(characterObj.characterData.ID, characterObj);

        //}

        //===============第一种逻辑  End


    }

    public override void Relese()
    {
        throw new System.NotImplementedException();
    }

    public override void Update()
    {

        //if（判断这个标记）
        //leftList或者rightList  遍历
        //characterLeftDic[i].Update()

        leftcharacterObj.Update();
        rightcharacterObj.Update();

    }

}
