﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CharacterModel : ModelBase
{
    public Dictionary<int, CharacterData> characterDic = new Dictionary<int, CharacterData>();

    public List<int> leftParticipationList = new List<int>();
    public List<int> rightParticipationList = new List<int>();

    //==左侧共同血量Data
    //==右侧共同血量Data

    //游戏初始化的时候服务器下发的角色所有信息，添加到库里
    public void AddCharacter(CharacterData characterData)
    {
        if(!characterDic.ContainsKey(characterData.ID))
            characterDic.Add(characterData.ID, characterData);
    }
  

    public CharacterData GetCharacterDataByID(int id)
    {
        return characterDic[id];
    }
    //===由选择上阵界面添加参展列表
    public void SetLeftParticipationList(int  characterID)
    {
        if (!leftParticipationList.Contains(characterID))
        {
            leftParticipationList.Add(characterID);
        }

    }
    //=====由服务器下发右侧参展列表
    public void SetRightParticipationList(int characterID)
    {
        rightParticipationList.Add(characterID);

    }


}
